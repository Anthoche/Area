import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';

type Automation = {
  id: string;
  title: string;
  runs: string;
  when: string;
  then: string;
};

type Stat = {
  id: string;
  title: string;
  value: string;
};

type Props = {
  onLogout: () => void;
};

const stats: Stat[] = [
  { id: 'total', title: 'Total', value: '4' },
  { id: 'active', title: 'Active', value: '3' },
  { id: 'paused', title: 'Paused', value: '1' },
  { id: 'runs', title: 'Runs', value: '238' },
];

const automations: Automation[] = [
  {
    id: '1',
    title: 'Welcome new users',
    runs: '47 runs',
    when: 'New user registered',
    then: 'Send email',
  },
];

export default function AutomationsScreen({ onLogout }: Props) {
  return (
    <ScrollView style={styles.root} contentContainerStyle={styles.container}>
      <Text style={styles.title}>Automations</Text>
      <Text style={styles.subtitle}>
        Create smart automations to connect your apps and streamline workflows
      </Text>

      <View style={styles.statsGrid}>
        {stats.map((item) => (
          <View key={item.id} style={styles.statCard}>
            <Text style={styles.statTitle}>{item.title}</Text>
            <Text style={styles.statValue}>{item.value}</Text>
          </View>
        ))}
      </View>

      <TouchableOpacity style={styles.createButton}>
        <Text style={styles.createText}>+  Create Automation</Text>
      </TouchableOpacity>

      <Text style={styles.sectionTitle}>Your Automations</Text>

      <View style={styles.list}>
        {automations.map((item) => (
          <View key={item.id} style={styles.card}>
            <View style={styles.cardHeader}>
              <View>
                <Text style={styles.cardTitle}>{item.title}</Text>
                <Text style={styles.cardRuns}>{item.runs}</Text>
              </View>
              <View style={styles.cardStatusRow}>
                <View style={styles.statusPill}>
                  <Text style={styles.statusText}>Active</Text>
                </View>
                <View style={styles.fakeSwitchOuter}>
                  <View style={styles.fakeSwitchInner} />
                </View>
                <TouchableOpacity onPress={onLogout}>
                  <Text style={styles.trash}>Delete</Text>
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.whenBlock}>
              <Text style={styles.blockLabel}>When</Text>
              <Text style={styles.blockText}>{item.when}</Text>
            </View>
            <View style={styles.separator} />
            <View style={styles.thenBlock}>
              <Text style={styles.blockLabel}>Then</Text>
              <Text style={styles.blockText}>{item.then}</Text>
            </View>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#F7EAF9',
  },
  container: {
    paddingHorizontal: 20,
    paddingTop: 28,
    paddingBottom: 32,
    gap: 18,
  },
  title: {
    color: '#1A1A1A',
    fontSize: 26,
    fontWeight: '700',
    textAlign: 'center',
  },
  subtitle: {
    color: '#666666',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    marginTop: 6,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    justifyContent: 'space-between',
  },
  statCard: {
    width: '48%',
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 20,
    elevation: 3,
    gap: 10,
  },
  statTitle: {
    fontSize: 14,
    color: '#666666',
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1A1A1A',
  },
  createButton: {
    height: 52,
    borderRadius: 26,
    backgroundColor: '#6C63FF',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    marginTop: 6,
    shadowColor: '#6C63FF',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.25,
    shadowRadius: 16,
    elevation: 6,
  },
  createText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1A1A1A',
    marginTop: 10,
  },
  list: {
    gap: 16,
    marginTop: 6,
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 22,
    padding: 18,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 20,
    elevation: 3,
    gap: 10,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
  },
  cardTitle: {
    color: '#1A1A1A',
    fontSize: 17,
    fontWeight: '700',
  },
  cardRuns: {
    color: '#666666',
    fontSize: 13,
  },
  cardStatusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  statusPill: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: '#E9E7FF',
    borderRadius: 14,
  },
  statusText: {
    color: '#6C63FF',
    fontWeight: '700',
    fontSize: 12,
  },
  fakeSwitchOuter: {
    width: 44,
    height: 26,
    borderRadius: 13,
    backgroundColor: '#8A7BFF',
    alignItems: 'flex-end',
    justifyContent: 'center',
    paddingHorizontal: 5,
  },
  fakeSwitchInner: {
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: '#FFFFFF',
  },
  trash: {
    fontSize: 14,
    color: '#666666',
  },
  whenBlock: {
    marginTop: 14,
    backgroundColor: '#8A2EFF',
    borderRadius: 20,
    padding: 16,
    gap: 6,
  },
  thenBlock: {
    backgroundColor: '#FF5C4D',
    borderRadius: 20,
    padding: 16,
    gap: 6,
  },
  blockLabel: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 12,
    letterSpacing: 0.3,
  },
  blockText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '600',
  },
  separator: {
    height: 8,
  },
});
