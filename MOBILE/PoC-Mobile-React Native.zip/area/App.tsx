import { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaView } from 'react-native';
import LoginScreen from './src/screens/LoginScreen';
import AutomationsScreen from './src/screens/AutomationsScreen';

export default function App() {
  const [loggedIn, setLoggedIn] = useState(false);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#0f172a' }}>
      {loggedIn ? (
        <AutomationsScreen onLogout={() => setLoggedIn(false)} />
      ) : (
        <LoginScreen onLogin={() => setLoggedIn(true)} />
      )}
      <StatusBar style="light" />
    </SafeAreaView>
  );
}
